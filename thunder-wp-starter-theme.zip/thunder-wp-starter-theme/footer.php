<?php
/**
 * The template for displaying footer
 *
 * @package ThunderWP
 * @since 1.0.0
 */

?>

<?php if ( ! function_exists( 'elementor_theme_do_location' ) || ! elementor_theme_do_location( 'footer' ) ) : ?>
	<footer id="footer">

	</footer><!--#footer-->
<?php endif ?>

<?php wp_footer(); ?>

</body>

</html>
