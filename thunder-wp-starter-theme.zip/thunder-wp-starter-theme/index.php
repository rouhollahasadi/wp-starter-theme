<?php
/**
 * Template for displaying index page
 *
 * @package ThunderWP
 * @since 1.0.0
 */

get_header();
?>


<?php
get_footer();
